import React, { useEffect, useCallback, useRef } from 'react'
import { useCreateBlockNote } from '@blocknote/react'
import { BlockNoteView } from '@blocknote/mantine'
import '@blocknote/core/fonts/inter.css'
import '@blocknote/mantine/style.css'
import { useAppStore } from '../stores/app-store'
import { useDebounce } from '../hooks/use-debounce'
import type { Block as NexusBlock } from '../../shared/types'
import { v4 as uuidv4 } from 'uuid'

interface Props {
  pageId: string
}

export function Editor({ pageId }: Props) {
  const { setSaveStatus, updatePage, currentPage } = useAppStore()
  const titleRef = useRef<HTMLTextAreaElement>(null)
  const initialContentLoaded = useRef(false)
  const currentPageId = useRef(pageId)
  const lastSavedBlocksSnapshot = useRef<string>('')
  const isMountedRef = useRef(true)

  const editor = useCreateBlockNote({
    domAttributes: { editor: { class: 'nx-editor-root' } },
  })

  // Load blocks from DB when pageId changes
  useEffect(() => {
    isMountedRef.current = true
    currentPageId.current = pageId
    initialContentLoaded.current = false

    async function load() {
      const blocks = await window.api.blocks.getByPageId(pageId)

      // Guard against stale loads if page switched during await
      if (currentPageId.current !== pageId) return

      if (blocks.length === 0) {
        const fallback = [{ type: 'paragraph', content: '' } as any]
        editor.replaceBlocks(editor.document, fallback)
        lastSavedBlocksSnapshot.current = ''
        initialContentLoaded.current = true
        return
      }

      const sorted = [...blocks].sort((a, b) => a.sort_order - b.sort_order)
      const parsedBlocks = sorted
        .map((b) => {
          try {
            return b.content ? JSON.parse(b.content) : null
          } catch {
            return null
          }
        })
        .filter(Boolean)

      editor.replaceBlocks(
        editor.document,
        parsedBlocks.length ? parsedBlocks : [{ type: 'paragraph', content: '' } as any]
      )

      lastSavedBlocksSnapshot.current = JSON.stringify(sorted.map((b) => b.content ?? ''))
      initialContentLoaded.current = true
    }

    load()

    return () => {
      isMountedRef.current = false
    }
  }, [pageId, editor])

  // Persist blocks to DB — skips if snapshot unchanged
  const persistBlocks = useCallback(
    async (nexusBlocks: NexusBlock[]) => {
      const nextSnapshot = JSON.stringify(nexusBlocks.map((b) => b.content))
      if (nextSnapshot === lastSavedBlocksSnapshot.current) return

      await window.api.blocks.save(currentPageId.current, nexusBlocks)
      lastSavedBlocksSnapshot.current = nextSnapshot
      setSaveStatus('saved')
      setTimeout(() => {
        if (isMountedRef.current) setSaveStatus('idle')
      }, 1200)
    },
    [setSaveStatus]
  )

  // Debounced block save
  const debouncedSave = useDebounce(
    useCallback(
      async (editorBlocks: any[]) => {
        if (!initialContentLoaded.current) return
        setSaveStatus('saving')

        const nexusBlocks: NexusBlock[] = editorBlocks.map((block, index) => ({
          id: block.id || uuidv4(),
          page_id: currentPageId.current,
          parent_block_id: null,
          block_type: block.type || 'paragraph',
          content: JSON.stringify(block),
          sort_order: index,
          created_at: '',
          updated_at: '',
        }))

        try {
          await persistBlocks(nexusBlocks)
        } catch {
          setSaveStatus('idle')
        }
      },
      [persistBlocks, setSaveStatus]
    ),
    500
  )

  // Debounced title save
  const debouncedTitleSave = useDebounce(
    useCallback(
      async (title: string) => {
        setSaveStatus('saving')
        try {
          await updatePage(currentPageId.current, { title })
          setSaveStatus('saved')
          setTimeout(() => {
            if (isMountedRef.current) setSaveStatus('idle')
          }, 1200)
        } catch {
          setSaveStatus('idle')
        }
      },
      [setSaveStatus, updatePage]
    ),
    500
  )

  // Title change handler with auto-resize
  const onTitleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const el = e.target
      el.style.height = 'auto'
      el.style.height = el.scrollHeight + 'px'
      debouncedTitleSave.call(el.value)
    },
    [debouncedTitleSave]
  )

  // Sync title textarea when page loads or changes
  useEffect(() => {
    if (!titleRef.current) return
    titleRef.current.value = currentPage?.title || ''
    titleRef.current.style.height = 'auto'
    titleRef.current.style.height = titleRef.current.scrollHeight + 'px'
  }, [pageId, currentPage?.title])

  // Flush all pending saves on unload / page switch
  useEffect(() => {
    const onBeforeUnload = () => {
      debouncedSave.flush()
      debouncedTitleSave.flush()
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [debouncedSave, debouncedTitleSave])

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto px-8 pt-6 pb-32" style={{ maxWidth: '760px' }}>
        {/* Page title */}
        <textarea
          ref={titleRef}
          defaultValue={currentPage?.title || ''}
          onChange={onTitleChange}
          placeholder="Untitled"
          rows={1}
          className="w-full bg-transparent text-[2rem] font-bold leading-[1.15] tracking-[-0.03em] text-[var(--nx-text)] placeholder:text-[var(--nx-text-tertiary)] resize-none outline-none border-none mb-2 overflow-hidden"
        />

        {/* Block editor */}
        <BlockNoteView
          editor={editor}
          theme="dark"
          onChange={() => {
            if (initialContentLoaded.current) {
              debouncedSave.call(editor.document as any)
            }
          }}
        />
      </div>
    </div>
  )
}
