import React from 'react'
import { useAppStore } from '../stores/app-store'

export function StatusBar() {
  const { saveStatus, currentPage } = useAppStore()

  return (
    <div className="h-7 flex items-center px-4 border-t border-[var(--nx-border-subtle)] text-[10px] text-[var(--nx-text-tertiary)] shrink-0 bg-[var(--nx-bg-secondary)]">
      <div className="flex-1">
        {currentPage && (
          <span className="uppercase tracking-[0.08em]">
            {currentPage.type_id === 'note' ? 'Note' : currentPage.type_id}
          </span>
        )}
      </div>
      <div className="flex items-center gap-1.5">
        {saveStatus === 'saving' && (
          <span className="flex items-center gap-1.5" style={{ animation: 'pulseGlow 1.5s ease infinite' }}>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400/80" />
            Saving
          </span>
        )}
        {saveStatus === 'saved' && (
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400/80" />
            Saved
          </span>
        )}
      </div>
    </div>
  )
}
